"""Script temporaneo: svuota DocumentRegistry e coda document-processing."""
from azure.data.tables import TableServiceClient
from azure.storage.queue import QueueClient

CONN = (
    "DefaultEndpointsProtocol=https;EndpointSuffix=core.windows.net;"
    "AccountName=devsaaimc;"
    "AccountKey=iU5aDuEBG3XAE+yEH2cVWPc4qsfJm8OPf7izXTYyb49GR9Tm3nIDSlJfoenqoLNbnP6/Q3xvO6M/+AStlgsIHA==;"
    "TableEndpoint=https://devsaaimc.table.core.windows.net/;"
    "QueueEndpoint=https://devsaaimc.queue.core.windows.net/"
)

# 1. Svuota DocumentRegistry
svc = TableServiceClient.from_connection_string(CONN)
tbl = svc.get_table_client("DocumentRegistry")
entities = list(tbl.list_entities())
print(f"DocumentRegistry: {len(entities)} entita trovate")
for e in entities:
    tbl.delete_entity(partition_key=e["PartitionKey"], row_key=e["RowKey"])
print("DocumentRegistry svuotata")

# 2. Svuota coda
q = QueueClient.from_connection_string(CONN, "document-processing")
q.clear_messages()
print("Coda document-processing svuotata")
